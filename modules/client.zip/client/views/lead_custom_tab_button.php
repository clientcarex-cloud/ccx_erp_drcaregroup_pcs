<script>console.log("✅ lead_custom_tab_button view loaded");</script>
<li role="presentation">
    <a href="#tab_client_profile" aria-controls="tab_client_profile" role="tab" data-toggle="tab">
        <i class="fa-solid fa-user-plus"></i> Client Profile
    </a>
</li>

