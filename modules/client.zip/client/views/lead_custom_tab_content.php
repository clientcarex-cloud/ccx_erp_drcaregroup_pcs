<script>console.log("✅ lead_custom_tab_content view loaded");</script>
<div role="tabpanel" class="tab-pane" id="tab_client_profile">
    <h4>Client Profile Content Here</h4>
    <!-- Your custom content for the client tab -->
</div>
