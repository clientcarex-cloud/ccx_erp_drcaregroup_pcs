<?php

defined('BASEPATH') or exit('No direct script access allowed');

$route['client/get_dynamic_options'] = 'client/get_dynamic_options';
$route['admin/client/doctor/calendar'] = 'client/doctor/calendar';
$route['admin/client/doctor/get_appointments_json'] = 'client/doctor/get_appointments_json';

